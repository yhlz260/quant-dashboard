# Deploy 11/ files to GitHub Pages via api.github.com (Contents API). Token read from file, deleted after.
$ErrorActionPreference = 'Stop'
$root   = 'c:/Users/zy/Desktop/quant-dashboard-recovered/11'
$tokFile = 'c:/Users/zy/Desktop/quant-dashboard-recovered/.github_token'
$repoName = 'quant-dashboard'

if(-not (Test-Path $tokFile)){ Write-Host 'ERROR: .github_token not found'; exit 1 }
$token = ((Get-Content $tokFile -Raw) -replace '[^A-Za-z0-9_]','')
if($token.Length -lt 20){ Write-Host 'ERROR: token format abnormal'; exit 1 }
Remove-Item $tokFile -Force
Write-Host 'token consumed and deleted'

$h = @{ Authorization = "Bearer $token"; Accept = 'application/vnd.github+json'; 'User-Agent' = 'deploy-script' }

# 1. identify account
$me = Invoke-RestMethod -Uri 'https://api.github.com/user' -Headers $h -TimeoutSec 30
$owner = $me.login
Write-Host ("account=" + $owner)

# 2. ensure repo exists (public required for free Pages)
$repoUrl = "https://api.github.com/repos/$owner/$repoName"
try {
  $repo = Invoke-RestMethod -Uri $repoUrl -Headers $h -TimeoutSec 30
  Write-Host ("repo exists, private=" + $repo.private)
  if($repo.private){ Write-Host 'WARN: repo is private; free plan cannot enable Pages on private repo' }
} catch {
  $body = @{ name = $repoName; private = $false; description = 'quant trading dashboard (triple-tier decision terminal)'; auto_init = $false } | ConvertTo-Json
  $repo = Invoke-RestMethod -Method Post -Uri 'https://api.github.com/user/repos' -Headers $h -Body $body -ContentType 'application/json' -TimeoutSec 30
  Write-Host 'repo created'
}

# 3. upload files via Contents API
$files = @('trading-dashboard.html','stock_page.html','stocks_map.json')
foreach($f in $files){
  $p = Join-Path $root $f
  $bytes = [System.IO.File]::ReadAllBytes($p)
  $b64 = [Convert]::ToBase64String($bytes)
  $api = "$repoUrl/contents/$f"
  $sha = $null
  for($try=0; $try -lt 4 -and -not $sha; $try++){
    try { $existing = Invoke-RestMethod -Uri ($api + '?ref=main') -Headers $h -TimeoutSec 30; $sha = $existing.sha } catch { if($try -eq 3 -and $_.Exception.Response -and $_.Exception.Response.StatusCode.Value__ -ne 404){ Start-Sleep -Seconds 5 } }
  }
  $payload = @{ message = "deploy $f"; content = $b64; branch = 'main' }
  if($sha){ $payload.sha = $sha }
  $json = $payload | ConvertTo-Json -Compress
  $ok = $false
  for($try=0; $try -lt 4 -and -not $ok; $try++){
    try { Invoke-RestMethod -Method Put -Uri $api -Headers $h -Body $json -ContentType 'application/json; charset=utf-8' -TimeoutSec 90 | Out-Null; $ok = $true }
    catch { Write-Host ("  retry " + ($try+1) + " for " + $f + ": " + $_.Exception.Message); Start-Sleep -Seconds 6 }
  }
  if(-not $ok){ Write-Host ("FAILED to upload " + $f); exit 1 }
  Write-Host ("uploaded " + $f + " (" + $bytes.Length + " bytes, replace=" + [bool]$sha + ")")
}

# 4. ensure Pages enabled from main root
try {
  Invoke-RestMethod -Uri "$repoUrl/pages" -Headers $h -TimeoutSec 30 | Out-Null
  Write-Host 'pages already enabled'
} catch {
  $src = @{ source = @{ branch = 'main'; path = '/' } } | ConvertTo-Json -Depth 5
  Invoke-RestMethod -Method Post -Uri "$repoUrl/pages" -Headers $h -Body $src -ContentType 'application/json' -TimeoutSec 30 | Out-Null
  Write-Host 'pages enabled (first build triggered)'
}

# 5. wait for build
$built = $false
for($i=0; $i -lt 40; $i++){
  Start-Sleep -Seconds 5
  try { $b = Invoke-RestMethod -Uri "$repoUrl/pages/builds/latest" -Headers $h -TimeoutSec 30 } catch { continue }
  Write-Host ("build status=" + $b.status)
  if($b.status -eq 'built'){ $built = $true; break }
  if($b.status -eq 'errored'){ Write-Host 'BUILD_ERRORED'; exit 1 }
}
$pageUrl = "https://$owner.github.io/$repoName"
if($built){
  Write-Host ("PAGES_READY " + $pageUrl + "/trading-dashboard.html")
  try {
    $resp = Invoke-WebRequest -Uri ($pageUrl + '/trading-dashboard.html?v=chk') -Method Head -UseBasicParsing -TimeoutSec 20
    Write-Host ("online size=" + $resp.Headers['Content-Length'])
  } catch { Write-Host ('note: direct fetch failed from this network (github.io may be blocked): ' + $_.Exception.Message) }
  exit 0
}
Write-Host 'BUILD_TIMEOUT (check later)'
exit 1
