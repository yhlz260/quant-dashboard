---
name: a-share-quant-terminal
version: 1.0.0
description: "构建与运维「A股三重仓职业决策终端」单文件 HTML 量化看板：P0 事件排雷（解禁/减持/财报一票否决+东财实时自动化）、P1 信号回测引擎+推荐跟踪闭环、P2 组合风控（大盘择时仓位/行业分散/相关性/等风险权重）。含东财+腾讯双源行情数据接口手册（精确 URL/字段/单位换算/CORS 实测结论/容灾链）、GitHub Pages API 免客户端自动部署脚本与 token 安全红线。当用户需要构建、修改、部署此类量化看板，复用 A 股数据接口方案，或需要可复制的投研-回测-风控方法论时使用。"
metadata:
  requires:
    bins: ["powershell"]        # 部署脚本运行环境；前端为纯静态单文件，无需构建
  files:
    - "src/trading-dashboard.html"   # 主终端（14 视图单文件应用，~130KB）
    - "src/stock_page.html"          # 个股详情页
    - "src/stocks_map.json"          # A股代码→名称映射数据（搜索用，330KB）
    - "scripts/deploy-gh-pages.ps1"  # GitHub Pages API 部署脚本（token 从文件读取，用完即删）
---

# A股三重仓职业决策终端（quant-terminal）

## 1. 何时使用本技能

- 用户要从零构建或修改一个 A 股行情/决策看板（无需后端，纯静态 HTML 可托管 GitHub Pages）
- 用户要给已有看板加：事件排雷、信号回测、推荐跟踪、组合风控中的任一模块
- 用户需要 A 股数据的**免费无鉴权接口**（实时行情/日K/财务/解禁）及其浏览器 CORS 可行性方案
- 用户要把静态站点自动部署到 GitHub Pages / Netlify（API 方式，免装 CLI）

## 2. 快速开始

```powershell
# 本地预览（项目根目录为 src/）
python -m http.server 9090 --directory src
# 浏览器打开 http://localhost:9090/trading-dashboard.html

# 部署上线（GitHub Pages，见第 6 节）
powershell -ExecutionPolicy Bypass -NoProfile -File scripts/deploy-gh-pages.ps1
```

已在 GitHub Pages 上线验证的实例：`https://yhlz260.github.io/quant-dashboard/trading-dashboard.html`（仓库 yhlz260/quant-dashboard，public）。换账号部署只需脚本里自动建仓库，无需改代码。

## 3. 架构总览（改代码前必读）

- **单文件原则**：主终端全部逻辑/样式/视图在一个 HTML 里（纯 vanilla JS，无构建链）。14 个视图靠 `.nav-item[data-view]` + `view-*` Tab 切换：仪表盘/持仓决策/风险排雷/信号雷达/回测/跟踪/组合风控/复盘/事件/缠论/复盘治理等。
- **主循环**：`render()` 每 10 秒重算全部视图；行情 fetchQuote 失败回退链见 data-apis.md。
- **日期单源**：顶部日期只用 `_WEEK/todayDate()/ymd()/todayLabel()/applyTodayLabels()`，禁止再写任何硬编码日期（历史 bug：页面日期停在旧日期）。
- **P0 数据自动化**：`refreshP0Live()` 首次进入自动拉东财实时财报+解禁（4 并发 worker，TTL 6h 缓存 `qd_p0cache_v2`），live 值覆盖手工 FUNDAMENTALS（pledge/gw/isFin 沿用手工）。
- **推荐跟踪闭环**：每日自动存档 `snapshotTodayRecommends()`（localStorage `qd_rec_archive_v1`），存档**必须先 `await ensureP0Live()`**，否则会用"数据未加载"的 P0 状态误存被否决标的（真实踩坑）。同理：**所有依赖 checkP0 判定的视图渲染前都必须 await ensureP0Live()**。
- **回测引擎**：5 信号 `BT_SIGNALS`，自包含指标（_btMA/_btEMA/_btRSI），回放从 i=120 开始，信号次日开盘买入，持有 5/10/20 日，止损收盘<MA20×0.95 / MACD 死叉止盈 / 到期，同信号冷却去重。**回测 K 线用 fqt=1 前复权**（详情页展示用 fqt=0，勿混用）。
- **localStorage keys**：`qd_p0cache_v2`（东财缓存 6h）、`qd_rec_archive_v1`（推荐存档）、各视图偏好。升级数据结构时换版本号，不做迁移兼容。

## 4. 数据接口 → 读 [references/data-apis.md](references/data-apis.md)

所有接口已实测（含浏览器 CORS 验证）。要点：东财主源 + 腾讯兜底 + 2 次重试是**必须的**（东财 push2/push2his 存在间歇性 ERR_EMPTY_RESPONSE 断连，跨天会变）；东财数值单位陷阱（解禁市值万元、财务字段倍数/每股/百分比混杂）全部在手册里。

## 5. 投研方法论 → 读 [references/methodology.md](references/methodology.md)

三层仓框架（长线/波段/短线 15/5/3 基线）、P0 排雷规则、P1 五信号定义与回测统计口径、P2 择时-仓位-等风险权重公式、P3 路线图。修改风控参数前先读。

**方法论参考库（doubao- 前缀文档，源自豆包侧 stock-pro-trader 技能）**：discipline（交易铁律）、screening-criteria（三面筛选）、tactics-library（战法库）、signal-library（信号库）、quant-factor-audit（回测防作弊审计）、review-lessons（复盘学习）、daily-review-flow（每日复盘流程）、visualization-spec（可视化规范），另见 scripts/calc.py（买卖点测算）与 assets/three-tier-model.html（三层仓模型模板）。**注意**：这些文档是决策纪律/选股思路参考；其中三层仓比例为 50/30/20，与本系统代码实现的 15/5/3 基线不同——**以代码实现为准**（src 是唯一可运行事实）；数据接口一律以本包 data-apis.md 实测版为准。

## 6. 部署（GitHub Pages API，免 CLI 免 git）

脚本 `scripts/deploy-gh-pages.ps1` 流程：读 `.github_token` → GET /user 验证 → 确保仓库存在（POST /user/repos）→ Contents API 上传 3 文件（PUT /repos/{o}/{r}/contents/{path}，替换需先 GET sha）→ POST /pages 启用 → 轮询 /pages/builds/latest 至 built → HEAD 校验线上 Content-Length。

**安全红线（不可违反）**：
1. token 禁止写入 Shell 命令行参数（会进进程列表与历史）
2. token 由用户提供，存入 `.github_token` 文件；脚本读取后**必须删除该文件**
3. 读取时用 `-replace '[^A-Za-z0-9_]',''` 清洗（用户从 Markdown 复制常带入反引号导致 401）
4. 经典 token ghp_ + scopes=repo 即够（建仓库+上传+Pages）；办公网 github.com 网页常被封，api.github.com 与 *.github.io 通常可达——token 创建需手机等外部网络
5. Pages 构建约 30-40s，构建窗口内页面 404 属正常，脚本已轮询等待

**Netlify 备选**（无 CLI）：POST /api/v1/sites/{siteId}/deploys 带 `{files:{/path:sha1}}` → PUT /api/v1/deploys/{id}/files/{name}（octet-stream 原始字节，非 zip）→ 轮询 ready。只 PUT 有变更文件，未变更文件 422 可忽略。

## 7. 已知坑清单（全部来自线上实测，改代码前过一遍）

1. **东财间歇断连**：push2/push2his 偶发 `net::ERR_EMPTY_RESPONSE`，同一浏览器稍后自愈。所有数据源必须 2 次重试 + 腾讯兜底，兜底接口 CORS 已实测可用。
2. **托管子路径坑**：GitHub Pages 挂在 `/{repo}/` 子路径下，页面内一切绝对路径 `/xxx` 都会 404（已修复 stock_page 返回按钮 `/trading-dashboard`→`trading-dashboard.html`）。Netlify→GitHub 迁移必查全部 href/fetch/window.open。
3. **本地代理依赖**：stock_page 的 PROXY=127.0.0.1:9091 仅本地开发有效，托管后对访客永远失败——线上必须靠东财/腾讯直连，不能靠代理兜底。
4. **P0 判定时序**：不 await ensureP0Live() 就过滤，会误放行被解禁/财报否决的标的（实测神华 217 亿解禁被放行过）。
5. **K 线复权**：回测 fqt=1，展示 fqt=0，跨模块复用数据时先确认复权口径。
6. **数值单位**：东财价格×100、解禁市值万元、ROE/净利已是百分数、每股现金流为元——换算规则见 data-apis.md，错一位就是 10 倍差。
7. **验证纪律**：一切"完成/成功/数值"结论必须绑定浏览器实测或终端输出证据（导航元素存在、KPI 值、线上 Content-Length 一致），禁止无证据宣称成功。
8. **localStorage 脏数据**：数据结构升级后旧 key 会污染判定，必要时指导用户清对应 key 重新生成。

## 8. 二次开发约定

- 新视图：加 `.nav-item[data-view=xxx]` + `view-xxx` 区块 + Tab 处理器；数据拉取函数命名 fetchXxx，渲染 renderXxxView
- 新数据源：先在浏览器 fetch 验证 CORS 与返回结构，再写解析；主源失败链：重试→腾讯→（本地 proxy 仅开发）
- 主题：CSS 变量 `--down`=红涨 `--up`=绿跌 `--accent` 橙 `--purple` `--grad` 蓝紫渐变；badge 类 b-buy/b-sell/b-wait
- 代码转换：`code2secid('sh600176')='1.600176'`（深市前缀 0.）；`code2secucode('sh600176')='600176.SH'`；腾讯接口直接用 sh/sz 原码
