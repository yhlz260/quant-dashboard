#!/usr/bin/env python3
"""A股三层仓职业决策测算工具
确定性计算一律用本脚本，不要手算。用法见文件底部示例。
"""
import math


def rebound_time(loss_rate: float, annual_return: float = 0.20) -> float:
    """回本所需年数（复利）
    loss_rate: 当前账户亏损比例，如 0.3 表示亏30%
    annual_return: 年化目标，默认0.20
    公式：ln(1/(1-loss)) / ln(1+annual_return)
    """
    if not (0 < loss_rate < 1):
        raise ValueError("loss_rate 必须在 (0,1) 之间")
    if annual_return <= 0:
        raise ValueError("annual_return 必须为正")
    return math.log(1 / (1 - loss_rate)) / math.log(1 + annual_return)


def rebound_needed(loss_rate: float) -> float:
    """回本所需涨幅（无复利口径）：亏损后回本要涨多少"""
    if not (0 < loss_rate < 1):
        raise ValueError("loss_rate 必须在 (0,1) 之间")
    return loss_rate / (1 - loss_rate)


def measured_move(neckline: float, low: float) -> float:
    """形态量度涨幅目标价（W底/头肩底/双底）
    目标价 = 颈线价 + (颈线价 - 形态最低点)
    """
    if neckline <= low:
        raise ValueError("颈线必须高于形态最低点")
    return neckline + (neckline - low)


def risk_reward(entry: float, target: float, stop: float) -> float:
    """盈亏比 = (目标-入场) / (入场-止损)
    要求 ≥2:1 才值得做
    """
    if entry <= stop:
        raise ValueError("入场价必须高于止损价")
    if target <= entry:
        raise ValueError("目标价必须高于入场价")
    return (target - entry) / (entry - stop)


def position_size(total_asset: float, weight: float, stop_pct: float,
                  risk_pct: float = 0.01) -> float:
    """基于总资产风险预算的反向仓位测算
    单票仓位 = 总资产×risk_pct / stop_pct
    risk_pct: 单票允许亏损占总资产比例（默认1%）
    stop_pct: 该票止损幅度（如0.08=8%）
    """
    if not (0 < stop_pct < 1) or not (0 < risk_pct < 1):
        raise ValueError("止损幅度与风险预算须在 (0,1) 之间")
    return total_asset * risk_pct / stop_pct


if __name__ == "__main__":
    print("=== 回本时间（年化20%复利）===")
    for r in (0.10, 0.20, 0.30, 0.40, 0.50):
        print(f"  亏损{r:.0%}：需涨{rebound_needed(r):.1%}，约{rebound_time(r):.1f}年回本")

    print("\n=== 量度涨幅（W底/头肩底）===")
    print("  例：形态低点15，颈线18 → 目标价", measured_move(18, 15))

    print("\n=== 盈亏比 ===")
    print("  例：入场20，目标23，止损18.5 → 盈亏比",
          round(risk_reward(20, 23, 18.5), 2))

    print("\n=== 反向仓位测算 ===")
    print("  例：总资产100万，止损8%，单票风险预算1% → 该票最多",
          round(position_size(1_000_000, 0.20, 0.08) / 10000, 1), "万元")
