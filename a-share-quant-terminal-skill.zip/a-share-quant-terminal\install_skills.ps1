﻿# A股三重仓决策终端 · 技能包一键安装（Windows PowerShell 版）
# 用法：powershell -ExecutionPolicy Bypass -NoProfile -File install_skills.ps1 [目标目录]
# 默认解压到当前目录下的 a-share-quant-terminal\
param([string]$Target = ".\a-share-quant-terminal")
$ErrorActionPreference = 'Stop'
$ZipUrl = 'https://raw.githubusercontent.com/yhlz260/quant-dashboard/main/a-share-quant-terminal-skill.zip'
$TmpZip = Join-Path $env:Temp ("aqt-skill-" + (Get-Date -UFormat %s) + ".zip")

Write-Host "===== A股三重仓决策终端 · 技能包安装 ====="
Write-Host ("目标目录: " + (Join-Path (Get-Location) $Target))
Write-Host ""

Write-Host "[1/4] 下载技能包..."
Invoke-WebRequest -Uri $ZipUrl -OutFile $TmpZip -UseBasicParsing -TimeoutSec 120
Write-Host ("下载完成: " + [math]::Round((Get-Item $TmpZip).Length/1KB) + " KB")

Write-Host ""
Write-Host "[2/4] 校验文件..."
Add-Type -AssemblyName System.IO.Compression.FileSystem
try { $a = [System.IO.Compression.ZipFile]::OpenRead($TmpZip); $n = $a.Entries.Count; $a.Dispose() }
catch { Write-Host "❌ ZIP 损坏，请重新运行"; exit 1 }
Write-Host ("✅ ZIP 校验通过（" + $n + " 个条目）")

Write-Host ""
Write-Host "[3/4] 解压到 $Target ..."
if(Test-Path $Target){ Remove-Item $Target -Recurse -Force }
Expand-Archive -Path $TmpZip -DestinationPath $Target -Force
# zip 内根目录为 a-share-quant-terminal/，若存在同名子目录则上提一层
$inner = Join-Path $Target 'a-share-quant-terminal'
if(Test-Path $inner){
  Get-ChildItem $inner -Force | Move-Item -Destination $Target -Force
  Remove-Item $inner -Force
}
Write-Host "✅ 解压完成"

Write-Host ""
Write-Host "[4/4] 验证安装结果..."
if(-not (Test-Path (Join-Path $Target 'SKILL.md'))){ Write-Host "❌ SKILL.md 缺失"; exit 1 }
if(-not (Test-Path (Join-Path $Target 'src\trading-dashboard.html'))){ Write-Host "❌ 源码缺失"; exit 1 }
Remove-Item $TmpZip -Force
Write-Host "🎉 安装完成！路径: " (Resolve-Path $Target)
Write-Host ""
Write-Host "快速开始:"
Write-Host ("  本地预览:  python -m http.server 9090 --directory " + (Join-Path (Resolve-Path $Target) 'src'))
Write-Host "  访问:      http://localhost:9090/trading-dashboard.html"
Write-Host "  在线实例:  https://yhlz260.github.io/quant-dashboard/trading-dashboard.html"
