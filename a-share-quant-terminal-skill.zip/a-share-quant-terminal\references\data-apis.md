# A股数据接口手册（全部经浏览器实测，2026-09 验证）

> 通用规则：所有接口免鉴权；浏览器直连依赖 CORS（文中标注实测结论）；主源失败自动重试 2 次，再切兜底源。东财间歇断连（ERR_EMPTY_RESPONSE）是常态，容灾链不可省略。

## 1. 代码格式转换

```js
// 东财 secid：沪市 1.，深市 0.
function code2secid(code){ var n=code.slice(2); return (code.slice(0,2)==='sh'?'1.':'0.')+n; }
// 东财 SECUCODE（财务/解禁 filter 用）
function code2secucode(code){ return code.slice(2)+(code.slice(0,2)==='sh'?'.SH':'.SZ'); }
// 腾讯直接用 sh600176 / sz000993 原码
```

## 2. 东财实时行情（主源，CORS ✓）

```
GET https://push2.eastmoney.com/api/qt/stock/get?secid=1.600176&fields=f43,f44,f45,f46,f47,f48,f57,f58,f169,f170&_={ts}
```
- 返回 `data.f43/f44/f45/f46` = 最高/最低/今开/现价，**价格字段一律 ×100**（除以 100 得元）
- `f47` 成交量（手）、`f48` 成交额（元）、`f57` 代码、`f58` 名称、`f169` 涨跌额（×100）
- 昨收需计算：preclose = current - change

## 3. 东财日 K 线（主源，CORS ✓）

```
GET https://push2his.eastmoney.com/api/qt/stock/kline/get?secid={secid}
    &fields1=f1,f2,f3,f4,f5,f6&fields2=f51,f52,f53,f54,f55,f56,f57,f58
    &klt=101&fqt={0|1}&beg=0&end=20500101&lmt={条数}&_={ts}
```
- `klt=101` 日线；**fqt=0 不复权（展示用）/ fqt=1 前复权（回测/收益率计算必须用）**
- `data.klines` 为字符串数组：`date,open,close,high,low,volume,amount,amplitude`

## 4. 东财财务摘要（P0 基本面自动化，CORS ✓）

```
GET https://datacenter.eastmoney.com/securities/api/data/v1/get?reportName=RPT_F10_FINANCE_MAINFINADATA
    &columns=SECUCODE,SECURITY_NAME_ABBR,REPORT_DATE,PARENTNETPROFITTZ,ZCFZL,MGJYXJJE,ROEJQ
    &filter=(SECUCODE%3D%22600176.SH%22)&pageSize=50&source=HSF10&client=PC&_={ts}
```
- 取最新 2 期做环比；字段含义：`PARENTNETPROFITTZ` 归母净利同比（**已是百分数**，73.87 = +73.87%）、`ZCFZL` 资产负债率（百分数）、`MGJYXJJE` 每股经营现金流（**元**）、`ROEJQ` 加权 ROE（百分数）
- `REPORT_DATE` 形如 `2026-06-30 00:00:00`，截日期部分展示

## 5. 东财限售解禁（P0 事件自动化，CORS ✓）

```
GET https://datacenter-web.eastmoney.com/api/data/v1/get?reportName=RPT_LIFT_STAGE
    &columns=SECURITY_CODE,SECURITY_NAME_ABBR,FREE_DATE,LIFT_MARKET_CAP,LIFT_REASON,PROPORTION
    &filter=(SECURITY_CODE%3D%22600176%22)(FREE_DATE%3E%3D%272026-09-14%27)(FREE_DATE%3C%3D%272026-12-13%27)
    &pageSize=50&source=WEB&client=WEB&_={ts}
```
- **`LIFT_MARKET_CAP` 单位是万元，÷10000 转亿元**（错一位差 1 万倍）
- filter 日期窗口：今日 ~ +90 日；分级：≥30亿 high（一票否决）/ ≥5亿 mid / 其余 low
- PowerShell 直测可用；浏览器实测 CORS ✓（datacenter 系两个域名都带 `Access-Control-Allow-Origin: *`）

## 6. 腾讯实时行情（行情兜底源，CORS ✓ 实测）

```
GET https://qt.gtimg.cn/q=sh600176&_={ts}
```
- 返回 GBK 文本：`v_sh600176="1~中国巨石~600176~44.82~..."`，**~ 分隔**
- 关键下标：`p[1]`名称 `p[3]`现价 `p[4]`昨收 `p[5]`今开 `p[6]`成交量(**手**) `p[32]`涨跌% `p[33]`最高 `p[34]`最低 `p[37]`成交额(**万元**)
- 解码：`new TextDecoder('gbk').decode(await resp.arrayBuffer())`（浏览器原生支持）

## 7. 腾讯前复权日 K（K 线兜底源，CORS ✓ 实测）

```
GET https://web.ifzq.gtimg.cn/appstock/app/fqkline/get?param=sh600176,day,,,320,qfq&_={ts}
```
- JSON：`data.sh600176.qfqday`（或 `.day`）为数组，项格式 `[date, open, close, high, low, volume, ...]`（字符串数字）

## 8. 大盘择时（regime 判定）

- 指数实时：上 `1.000001` 深 `0.399001` 创 `0.399006`，用第 2 节接口分别取 f170 涨跌幅，三指数均值
- 兜底：东财 K 线接口 `secid=1.000001` 取最近日 K 涨跌幅（实时接口全断时用）
- 映射：均值 ≥+1% 强势（仓位×1.0）/ -1%~+1% 震荡（×0.6）/ ≤-1% 弱势（×0.4，只低吸）

## 9. 容灾链模板（照抄即可）

```js
async function fetchX(code){
  for(var i=0;i<2;i++){ try{ /* 东财主源 */ return parseEM(...); }catch(e){ if(i===1) console.warn('em retry failed',e); } }
  try{ /* 腾讯兜底 */ return parseTX(...); }catch(e2){ console.warn('tencent failed',e2); }
  try{ /* 本地 proxy 仅开发用（127.0.0.1:9091），托管后必失败 */ }catch(e3){}
  return null; // 上层显示"数据加载失败"，禁止静默吞错
}
```

## 10. CORS 实测结论速查（2026-09-14）

| 域名 | CORS | 用途 |
|---|---|---|
| push2.eastmoney.com | ✓ | 实时行情 |
| push2his.eastmoney.com | ✓（偶发断连需重试） | 日K |
| datacenter(.web).eastmoney.com | ✓ | 财务/解禁 |
| qt.gtimg.cn | ✓（GBK） | 实时行情兜底 |
| web.ifzq.gtimg.cn | ✓ | 日K兜底 |
| hq.sinajs.cn | ✗（需 Referer） | 不可用于纯前端 |
