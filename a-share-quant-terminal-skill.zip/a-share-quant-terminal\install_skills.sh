#!/bin/bash
# A股三重仓决策终端 · 技能包一键安装脚本
# 用法：bash install_skills.sh [目标目录]
# 默认解压到当前目录下的 a-share-quant-terminal/
# 包内容：SKILL.md（主技能）+ references（数据接口手册+方法论+doubao参考库）
#        + scripts（部署/测算）+ assets + src（可直接部署的看板源码）

set -e

ZIP_URL="https://raw.githubusercontent.com/yhlz260/quant-dashboard/main/a-share-quant-terminal-skill.zip"
TARGET="${1:-./a-share-quant-terminal}"
TMP_ZIP="/tmp/aqt-skill-$(date +%s).zip"

echo "===== A股三重仓决策终端 · 技能包安装 ====="
echo "目标目录: $TARGET"
echo ""

# 1. 下载
echo "[1/4] 下载技能包..."
curl -L --retry 3 -o "$TMP_ZIP" "$ZIP_URL"
echo "下载完成: $(du -h "$TMP_ZIP" | cut -f1)"

# 2. 校验
echo ""
echo "[2/4] 校验文件..."
if ! unzip -t "$TMP_ZIP" > /dev/null 2>&1; then
  echo "❌ ZIP 文件损坏，请重新运行"
  exit 1
fi
echo "✅ ZIP 校验通过"

# 3. 解压
echo ""
echo "[3/4] 解压到 $TARGET ..."
rm -rf "$TARGET"
mkdir -p "$TARGET"
unzip -q -o "$TMP_ZIP" -d "$TARGET"
# zip 内根目录为 a-share-quant-terminal/，若解压出同名子目录则上提一层
if [ -d "$TARGET/a-share-quant-terminal" ]; then
  shopt -s dotglob
  mv "$TARGET/a-share-quant-terminal"/* "$TARGET/"
  rmdir "$TARGET/a-share-quant-terminal"
  shopt -u dotglob
fi
echo "✅ 解压完成"

# 4. 验证
echo ""
echo "[4/4] 验证安装结果..."
[ -f "$TARGET/SKILL.md" ] && echo "✅ SKILL.md 就位" || { echo "❌ SKILL.md 缺失"; exit 1; }
[ -f "$TARGET/src/trading-dashboard.html" ] && echo "✅ 看板源码就位" || { echo "❌ 源码缺失"; exit 1; }
echo ""
echo "🎉 安装完成！路径: $(cd "$TARGET" && pwd)"
echo ""
echo "目录结构:"
echo "  $TARGET/"
echo "  ├── SKILL.md              (主技能：架构/坑清单/部署红线)"
echo "  ├── references/           (data-apis实测接口手册 + 方法论 + doubao参考库)"
echo "  ├── scripts/              (deploy-gh-pages.ps1 部署 / calc.py 测算)"
echo "  ├── assets/               (三层仓模型模板)"
echo "  └── src/                  (可运行看板：trading-dashboard.html 主终端 / stock_page.html 个股页 / stocks_map.json)"
echo ""
echo "快速开始:"
echo "  本地预览:  python3 -m http.server 9090 --directory $TARGET/src"
echo "  访问:      http://localhost:9090/trading-dashboard.html"
echo "  在线实例:  https://yhlz260.github.io/quant-dashboard/trading-dashboard.html"

# 清理
rm -f "$TMP_ZIP"
